<table>
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            Return Period (Years)
        </th>
        <th style="color: #ffffff;background-color: #343A40">
           2
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            5
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            10
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            25
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            50
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            100
        </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td style="color: #ffffff;background-color: #343A40">A</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
    </tr>
    <tr>
        <td style="color: #ffffff;background-color: #343A40">B</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
    </tr>
    <tr>
        <td style="color: #ffffff;background-color: #343A40">D</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
    </tr>
    </tbody>
</table>
