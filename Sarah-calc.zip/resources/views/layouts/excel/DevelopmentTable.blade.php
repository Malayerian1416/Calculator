<table>
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            Land Use
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            Area (m<sup>2</sup>)
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            Runoff C
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            Impervious
        </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
