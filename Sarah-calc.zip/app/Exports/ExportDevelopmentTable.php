<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportDevelopmentTable implements FromView,WithStyles,WithTitle
{
    public function styles(Worksheet $sheet): void
    {
        $sheet->getStyle('A:D');
        $sheet->getStyle('A:D')->getFont()->setSize(12);
        $sheet->getStyle('A1:D1')->getFont()->setSize(12);
        $sheet->getStyle('A:D')->getAlignment()->setVertical('center');
        $sheet->getStyle('A:D')->getAlignment()->setHorizontal('center');
        $sheet->getColumnDimension('A')->setWidth(40);
        $sheet->getColumnDimension('B')->setWidth(20);
        $sheet->getColumnDimension('C')->setWidth(20);
        $sheet->getColumnDimension('D')->setWidth(20);
    }

    public function view(): View
    {
        return view('layouts.excel.DevelopmentTable');
    }

    public function title(): string
    {
        return "DevelopmentTable";
    }
}
